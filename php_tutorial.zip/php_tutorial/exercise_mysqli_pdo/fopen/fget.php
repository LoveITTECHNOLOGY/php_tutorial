<?php
$file=fopen("d:\\php\\text.txt","r");
while(!feof($file)){
    $str=fgets($file); //读取文件中的一行，读取完后指针会指向下一行
    echo $str."<br>";

}
fclose($file); //关闭文件
?>