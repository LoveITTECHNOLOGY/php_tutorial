<?php
//打开文件
$file=fopen("d:\\php\\text.txt","r");
echo $file;
$t=fopen("http://www.baidu.com","r");
//echo $t;
$str=fread($file,filesize("d:\\php\\text.txt"));
//将内容换行
echo nl2br($str);
//只读取部分内容
//$s=fread($file,12);
//echo $s;
fclose($file);

?>