<?php
$num=0;//$num用来统计子目录和文件的总数
$dir='/myBBS/work';
$dirth=opendir($dir);
?>
<table border="1" width="600">
    <caption><b>目录<?php echo $dir;?>中的内容</b></caption>
    <tr align="left" bgcolor="#faebd7">
        <th>文件名</th><th>大小</th><th>类型</th><th>修改时间</th>
        <?php
           while($file=readdir($dirth)){
               if($file!='.'&&$file!==".."){
                   $dirfile=$dir."/".$file;
                   $num++;
                   $bgcolor='#faebd7';
                   echo '<tr bgcolor='.$bgcolor.'>';
                   echo '<td>'.$file.'</td>';
                   echo '<td>'.$filesize($file).'</td>';
                   echo '<td>'.$filetype($file).'</td>';
                   echo '<td>'.date("Y/n/t",filemtime($dirfile)).'</td>';
               }

           }
        closedir($dir);
        ?>
    </tr>
</table>
在<b><?php echo $dir; ?></b>目录下的子目录和文件共有<b><?php echo $num;?></b>