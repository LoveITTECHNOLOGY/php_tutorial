<?php
$file='text.txt';
echo "<br>文件名; ".basename($file);
$patharr=pathinfo($file);
echo "<br>文件名扩展名:".$patharr['extension'];
echo "<br>文件的属性:".filetype($file);
echo "<br>文件的路径:".realpath($file);
echo "<br>文件的大小:".filesize($file);
echo "<br>文件创建的时间:".date('Y-m-d H:s:i',filectime($file));
?>