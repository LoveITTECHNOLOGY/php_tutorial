<?php
if(copy('test.txt','../copy/tt.txt'))
echo "文件复制成功!";
else
    echo "文件复制失败1";
unlink('test.txt');

?>
<html>
<meta charset="UTF-8">
</html>