<?php
session_start();
$f=fopen("time.txt",'r+');
$visit=fgets($f);
//$_SESSION['connected']=null;
//防刷机制
if(!$_SESSION['connected'])
{
    $visit=$visit+1;
    $_SESSION['connected']=true;
}
$countlen=strlen($visit);
$num=null;
for($i=0;$i<$countlen;$i++)
    $num=$num."<img src=img/".substr($visit,$i,1). ".gif></img>";

rewind($f);
fwrite($f,$visit);
fclose($f);
echo $visit;

?>
<html>
<meta charset="UTF-8">
<body>
<h2>欢迎来我的主页</h2>
<hr>你是第<?php echo $num;?>位访问者!

</body>
</html>

