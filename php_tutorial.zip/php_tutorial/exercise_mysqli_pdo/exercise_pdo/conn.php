<?php
//创建对象
$dsn="mysql:host=localhost;dbname=mybook";
//连接数据库
$db=new PDO($dsn,'root','');
$db->query('set names utf8');
/*$result=$db->query("select * from user");
$result->setFetchMode(PDO::FETCH_ASSOC);
$row=$result->fetch();
echo $row['name'];*/

?>