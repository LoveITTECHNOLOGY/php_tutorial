<?php
require('conn.php');
$sql='insert into user(name,sex,age,addr,tel) VALUES (?,?,?,?,?)';
$stmt=$db->prepare($sql);
$stmt->bindParam(1,$name);
$stmt->bindParam(2,$sex);
$stmt->bindParam(3,$age);
$stmt->bindParam(4,$addr);
$stmt->bindParam(5,$tel);
$stmt->execute();
//插入第二条
$name='王翔'; $sex='男';$age=23; $addr='江西景德镇';$tel='1254';
$stmt->execute();
$name='刘敏'; $sex='女';$age=25;$addr='江西九江';$tel='1234';
$stmt->execute();
$name='刘男'; $sex='男';$age=15;$addr='甘肃兰州';$tel='1235';
$stmt->execute();
$name='刘小'; $sex='女';$age=22;$addr='甘肃武威';$tel='1238';
$stmt->execute();
$name='刘化'; $sex='女';$age=23;$addr='甘肃酒泉';$tel='1230';
$stmt->execute();
$name='刘看'; $sex='女';$age=15;$addr='甘肃定西';$tel='1233';
$stmt->execute();
?>