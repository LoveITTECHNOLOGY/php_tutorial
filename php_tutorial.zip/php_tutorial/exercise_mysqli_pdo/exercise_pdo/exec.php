<?php
require('conn.php');
//改进内容
//$aff=$db->exec("update user set name='张四' WHERE numer=1");
//echo $aff;
//增加内容
//$aff=$db->exec("insert into user(numer,name,sex,addr,age,tel) VALUES (1,'匿名','男','安徽','24','123455565')");
//echo $aff;
//删除内容
$aff=$db->exec("delete from user where age<20");
echo $aff;
?>