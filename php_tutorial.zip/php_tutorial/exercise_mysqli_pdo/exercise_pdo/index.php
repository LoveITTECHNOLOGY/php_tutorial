<?php
require('conn.php');
$result=$db->query("select * from user");
$result->setFetchMode(PDO::FETCH_ASSOC);
//$row=$result->fetch();
//echo $row['name'];
?>

    <body bgcolor="#ffe4c4">
    <h2 align="center">欢迎来到人事管理系统</h2>
    <table border="0" width="95%" align="center">
        <tr><td><a href="register_1.php">增加人员信息</a></td>
            <td>
                <form method="get" action="chaxun.php">
                    <div style="....">


                        查找人员，请输入查询关键字<input name="keyword" type="text">
                        <select name="sel">

                            <option value="name">姓名</option>
                            <option value="sex">性别</option>
                            <option value="age">年龄</option>
                            <option value="addr">住址</option>
                        </select>
                        <input type="submit"  value="查询">
                    </div>



                </form>


            </td>
        </tr>
    </table>
    <table border="1" width="95%">

        <tr bgcolor="#deb887">
            <th>序号</th>
            <th>姓名</th>
            <th>性别</th>
            <th>年龄</th>
            <th>家庭住址</th>
            <th>手机号码</th>
            <th>删除</th>
            <th>操作</th>
        </tr>

        <?php
      while($rows=$result->fetchAll()){
          foreach($rows as $row)
          {



            ?>
            <tr>
                <td><?php echo $row['numer'];?></td>
                <td><?php echo $row['name'];?></td>
                <td><?php echo $row['sex'];?></td>
                <td><?php echo $row['age'];?></td>
                <td><?php echo $row['addr'];?></td>
                <td><?php echo $row['tel'];?></td>
                <td align="center"><a href="delete.php?id=<?php echo $row['numer'];?>">删除</a> </td>
                <td align="center"><a href="update.php?id=<?php echo $row['numer'];?>">修改</a> </td>



            </tr>
        <?php
        } }?>
