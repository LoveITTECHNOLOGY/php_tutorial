<?php
$conn=mysqli_connect("localhost","root","","mybook");
$conn->set_charset("UTF8");
?>