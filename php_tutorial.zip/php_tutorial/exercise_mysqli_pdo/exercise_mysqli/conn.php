<?php
//普通mysqli的连接方式
$conn=mysqli_connect("localhost","root","","mybook");
//pdo类访问数据库的方式
//
//$conn=new mysqli("localhost","root","","mybook");
/*
//mysqli的类的连接方式
$conn=new mysqli();
$conn->connect("localhost","root","");
$conn->select_db("mybook");*/
$conn->set_charset("UTF8");
//$result=mysqli_query($conn,"select * from user");
$result=$conn->query("select * from user");
$row=$result->fetch_assoc();
//echo $row['name'];
$t=$result->num_rows;
echo $t;

/*
if($conn)
    echo "数据库连接成功";
else
    echo "连接失败!";
*/
?>