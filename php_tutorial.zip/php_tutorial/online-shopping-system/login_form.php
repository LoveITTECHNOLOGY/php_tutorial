<?php
#this是“登录表单”页面，如果用户已经登录，那么我们将不允许用户通过执行isset（$ _ SESSION [“ uid”]）访问该页面
//＃如果以下声
///返回true，那么我们会将用户发送到他们的profile.php页面
//在action.php页面中，如果用户单击“准备签出”按钮，那么我们将以action.php页面的形式传递数据
if (isset($_POST["login_user_with_product"])) {
//这是产品列表数组
	$product_list = $_POST["product_id"];
    //这里我们将数组转换为json格式，因为数组无法存储在cookie中
	$json_e = json_encode($product_list);
    //我们在这里创建cookie，cookie的名称为product_list
	setcookie("product_list",$json_e,strtotime("+1 day"),"/","","",TRUE);

}
mysql_query("set names 'UTF8'");
?>

	<div class="wait overlay">
		<div class="loader"></div>
	</div>
	<div class="container-fluid">
				<!-- 行 -->
				

					<div class="login-marg">
						<!-- 账单信息-->


                        <!-- 账单信息-->
						
						
								<form onsubmit="return false" id="login" class="login100-form ">
									<div class="billing-details jumbotron">
                                    <div class="section-title">
                                        <h2 class="login100-form-title p-b-49" >在此登录</h2>
                                    </div>
                                   
                                    
                                    <div class="form-group">
                                       <label for="email">电子邮件</label>
                                        <input class="input input-borders" type="email" name="email" placeholder="邮箱" id="password" required>
                                    </div>
                                    
                                    <div class="form-group">
                                       <label for="email">密码</label>
                                        <input class="input input-borders" type="password" name="password" placeholder="密码" id="password" required>
                                    </div>
                                    
                                    <div class="text-pad" >
                                       <a href="#">
                                           忘记密码 ？
                                       </a>
                                        
                                    </div>
                                    
                                        <input class="primary-btn btn-block"   type="submit"  Value="登录">
                                        
                                        <div class="panel-footer"><div class="alert alert-danger"><h4 id="e_msg"></h4></div></div>
                                    
                                    	
                                        
                                    

                                </div>
                                
								</form>
                           
						<!-- 邮费信息 -->

                        <!-- 邮费信息 -->

						<!-- 顾客账单 -->

                        <!-- 顾客账单 -->
					</div>
        <!-- 顾客账单 -->

        <!-- 顾客账单 -->
				
				<!-- /行-->
			</div>