<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "ecommerce";

// 开始连接数据库
$con = mysqli_connect($servername, $username, $password,$db);
//开始将查询的内容设置成中文
mysqli_query($con,"set names utf8");

// 检查是否连接失败
if (!$con) {
    die("连接失败: " . mysqli_connect_error());
}


?>