<meta charset="UTF-8">
<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据表名
mysql_select_db("ecommerce",$conn);
//开始将连接表名设置为中文字符
mysql_query("set names 'UTF8'");
$PageSize=5;

//开始执行sql语句
$result=mysql_query("select count(*)  from email_info",$conn);
$row=mysql_fetch_row($result);


$RecordCount=$row[0];
$PageCount=ceil($RecordCount/$PageSize);
//开始释放资源
mysql_free_result($result);
if(isset($_GET['page'])&&(int)$_GET['page']>0)
    $page=$_GET['page'];
else   $page=1;
//$result=mysql_query("select * from user limit ".($page-1)*$PageSize.",".$PageSize,$conn);
//结果集
$result=mysql_query("select *  from email_info");



?>
<body bgcolor="#ffe4c4">
<h2 align="center">欢迎来到用户邮件管理系统</h2>
<table border="0" width="95%" align="center">
    <tr><td><a href="register_email.php">增加用户邮件信息</a></td>
        <td>
            <form method="get" action="email_manage_chaxun.php">
                <div style="....">


                    查找邮箱，请输入查询关键字<input name="keyword" type="text">
                    <select name="sel">
                        <option value="email">个人邮件查询</option>
                    </select>
                    <input type="submit"  value="查询">
                </div>



            </form>


        </td>
    </tr>
</table>
<table border="1" width="95%">

    <tr bgcolor="#deb887">
        <th>序号</th>
        <th>个人用户邮箱</th>
    </tr>



    <?php
    //通过指针定位来实现分页 1，2，3
    mysql_data_seek($result,($page-1)*$PageSize);
    for($i=0;$i<$PageSize;$i++){
        $row=mysql_fetch_assoc($result);
        if($row){


            ?>

            <tr>
                <td><?php echo $row['email_id'];?></td>
                <td><?php echo $row['email'];?></td>
                <td align="center"><a href="email_delete.php?id=<?php echo $row['email_id'];?>">删除</a> </td>
                <td align="center"><a href="email_update.php?id=<?php echo $row['email_id'];?>">修改</a> </td>



            </tr>
        <?php }}
    mysql_free_result($result);
    ?>
</table>
<p align="center">
    <?php
    if($page==1)
        echo "首页 上一页";
    else
        echo "<a href='?page=1'>首页</a>
    <a href='?page=".($page-1)."'>上一页</a>";
    for($i=1;$i<=$PageCount;$i++){
        if($i==$page)echo "$i ";
        else echo "<a href='?page=$i'>$i </a>";

    }
    if($page==$PageCount)
        echo "下一页 末页";
    else
        echo "<a href='?page=".($page+1)."'>下一页</a>
    <a href='?page=".$PageCount."'>末页</a>";
    echo "&nbsp 共".$RecordCount."条记录&nbsp";
    echo "$page/$PageCount 页";





    ?>


</p>
</body>