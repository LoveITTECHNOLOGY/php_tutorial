<?php
include 'header.php';
?>
     <script id="jsbin-javascript">
(function (global) {
	if(typeof (global) === "未定义")
	{
		throw new Error("窗口未定义");
	}
    var _hash = "!";
    var noBackPlease = function () {
        global.location.href += "#";
        //确保我们有可用于果汁的水果...
//只需50毫秒就不会花费太多（^ __ ^）
        global.setTimeout(function () {
            global.location.href += "!";
        }, 50);
    };
    //之前我们在这里设置了setInerval ....
    global.onhashchange = function () {
        if (global.location.hash !== _hash) {
            global.location.hash = _hash;
        }
    };
    global.onload = function () {        
		noBackPlease();
        //在输入字段和textarea上禁用页面上的退格键。
		document.body.onkeydown = function (e) {
            var elm = e.target.nodeName.toLowerCase();
            if (e.which === 8 && (elm !== 'input' && elm  !== 'textarea')) {
                e.preventDefault();
            }
            //停止使DOM树冒泡的事件。
            e.stopPropagation();
        };		
    };
})(window);
</script>
      <div class="main main-raised"> 
        
		<div class="section">

			<div class="container">
				<!-- 行 -->
				<div class="row">
					<!-- 一边 -->
					<div id="aside" class="col-md-3">
						<!--另一边组件 -->
						<div id="get_category">
				        </div>
						<!-- /另一边组件 -->

                        <!-- /另一边组件 -->
						<div class="aside">
							<h3 class="aside-title">价钱</h3>
							<div class="price-filter">
								<div id="price-slider" class="noUi-target noUi-ltr noUi-horizontal"><div class="noUi-base"><div class="noUi-origin" style="left: 0%;"><div class="noUi-handle noUi-handle-lower" data-handle="0" tabindex="0" role="slider" aria-orientation="horizontal" aria-valuemin="0.0" aria-valuemax="100.0" aria-valuenow="0.0" aria-valuetext="1.00" style="z-index: 5;"></div></div><div class="noUi-connect" style="left: 0%; right: 0%;"></div><div class="noUi-origin" style="left: 100%;"><div class="noUi-handle noUi-handle-upper" data-handle="1" tabindex="0" role="slider" aria-orientation="horizontal" aria-valuemin="0.0" aria-valuemax="100.0" aria-valuenow="100.0" aria-valuetext="999.00" style="z-index: 4;"></div></div></div></div>
								<div class="input-number price-min">
									<input id="price-min" type="number">
									<span class="qty-up">+</span>
									<span class="qty-down">-</span>
								</div>
								<span>-</span>
								<div class="input-number price-max">
									<input id="price-max" type="number">
									<span class="qty-up">+</span>
									<span class="qty-down">-</span>
								</div>
							</div>
						</div>
                        <!-- /另一边组件 -->

                        <!-- /另一边组件 -->
						<div id="get_brand">
				        </div>
                        <!-- /另一边组件 -->

                        <!-- /另一边组件 -->
						<div class="aside">
							<h3 class="aside-title">最畅销</h3>
							<div id="get_product_home">
								<!-- 产品组件· -->

                                <!-- 产品组件· -->
							</div>
						</div>
                        <!-- /另一边组件 -->
					</div>
					<!-- /另一边-->

					<!-- 商店 -->
					<div id="store" class="col-md-9">

						<div class="store-filter clearfix">
							<div class="store-sort">
								<label>
                                    排序方式：
									<select class="input-select">
										<option value="0">流行</option>
										<option value="1">位置</option>
									</select>
								</label>

								<label>
                                    显示：
									<select class="input-select">
										<option value="0">20</option>
										<option value="1">50</option>
									</select>
								</label>
							</div>
							<ul class="store-grid">
								<li class="active"><i class="fa fa-th"></i></li>
								<li><a href="#"><i class="fa fa-th-list"></i></a></li>
							</ul>
						</div>



						<div class="row" id="product-row">
						<div class="col-md-12 col-xs-12" id="product_msg">
					</div>

							<div id="get_product">

						</div>


						</div>

						<div class="store-filter clearfix">
							<span class="store-qty">显示20-100产品</span>
							<ul class="store-pagination" id="pageno">
								<li ><a class="active" href="#aside">1</a></li>
								
								<li><a href="#"><i class="fa fa-angle-right"></i></a></li>
							</ul>
						</div>

					</div>
					<!-- /商店 -->
				</div>
				<!-- /行 -->
			</div>
			<!-- /容器-->
		</div>
</div>
<?php
include "newslettter.php";
include "footer.php";
?>