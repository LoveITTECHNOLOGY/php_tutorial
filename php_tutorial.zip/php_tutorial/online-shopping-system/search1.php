<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/search1.css">
</head>
<body>
<meta charset="UTF-8">
<h2 align="center" style="color: #00bf9a">欢迎来到购物查询系统</h2>
<h1 style="float: right"><a href="index.php"> <i class="fas fa-undo"></i>返回</a></h1>
<div class="table1">
<table border="0" width="20px" align="center"  class="table1" style="color: #00bf9a">
        <td>

            <i class="fas fa-search"></i>用户查询 <form method="get" action="chaxun.php">
                <div style="....">
                    <input name="keyword" type="text">
                    <select name="sel">

                        <option value="first_name" style="color: #00bf9a">姓</option>
                        <option value="last_name" style="color: #00bf9a">名</option>
                        <option value="email" style="color: #00bf9a">邮件</option>
                        <option value="address1" style="color: #00bf9a">住址</option>
                    </select>
                    <input type="submit"  value="查询">
                </div>



            </form>


        </td>
    </tr>
</table>
</div>
<div class="slidershow middle">
    <div class="slides">
        <input type="radio" name="r" id="r1" checked>
        <input type="radio" name="r" id="r2">
        <input type="radio" name="r" id="r3">
        <input type="radio" name="r" id="r4">
        <input type="radio" name="r" id="r5">
        <div class="slide s1">
            <img src="./img/1.jpg">
        </div>
        <div class="slide">
            <img src="./img/2.jpg">
        </div>
        <div class="slide">
            <img src="./img/3.jpg">
        </div>
        <div class="slide">
            <img src="./img/4.jpg">
        </div>
        <div class="slide">
            <img src="./img/5.jpg">
        </div>
        <div class="navigation">
            <label for="r1" class="bar"></label>
            <label for="r2" class="bar"></label>
            <label for="r3" class="bar"></label>
            <label for="r4" class="bar"></label>
            <label for="r5" class="bar"></label>

        </div>
    </div>
</div>
</body>
</html>