<html>
<meta charset="UTF-8">
<body bgcolor="#f0ffff">
<p align="center">请填写用户邮箱信息</p>

<form action="email_check.php" method="post">
    <table border="1" align="center">
        <tr><th>用户邮箱<input type="text" name="email">*</th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>



    </table>
</form>

</body>
</html>