<html>
<meta charset="UTF-8">
<body bgcolor="#f0ffff">
<p align="center">请填写个人信息</p>

<form action="admin_check.php" method="post">
    <table border="1" align="center">
        <tr><th>管理员<input type="text" name="admin_name">*</th></tr>
        <tr><th> <br>管理员邮箱<input type="text" name="admin_email">*</br></th></tr>
        <tr><th><br>管理员密码<input type="text" name="admin_password">*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>



    </table>
</form>

</body>
</html>