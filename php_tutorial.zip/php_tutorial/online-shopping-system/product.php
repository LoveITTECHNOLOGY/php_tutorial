<?php
include "header.php";
mysql_query("set names 'UTF8'");
?>
		<!-- /布局· -->
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script>
		<script>
    
    (function (global) {
	if(typeof (global) === "undefined")
	{
		throw new Error("window is undefined");
	}
    var _hash = "!";
    var noBackPlease = function () {
        global.location.href += "#";
        //确保我们有可用于果汁的水果...
//只需50毫秒就不会花费太多（^ __ ^）
        global.setTimeout(function () {
            global.location.href += "!";
        }, 50);
    };
        //之前我们在这里设置了setInerval ....
    global.onhashchange = function () {
        if (global.location.hash !== _hash) {
            global.location.hash = _hash;
        }
    };
    global.onload = function () {        
		noBackPlease();
        //在输入字段和textarea上禁用页面上的退格键。
		document.body.onkeydown = function (e) {
            var elm = e.target.nodeName.toLowerCase();
            if (e.which === 8 && (elm !== 'input' && elm  !== 'textarea')) {
                e.preventDefault();
            }
            //停止使DOM树冒泡的事件。
            e.stopPropagation();
        };		
    };
})(window);
</script>


		<div class="section main main-raised">
			<!-- 容器-->
			<div class="container">
				<!-- 行-->
				<div class="row">

					
					<?php 
								include 'db.php';
								$product_id = $_GET['p'];
								
								$sql = " SELECT * FROM products ";
								$sql = " SELECT * FROM products WHERE product_id = $product_id";
								if (!$con) {
									die("连接失败: " . mysqli_connect_error());
								}
								$result = mysqli_query($con, $sql);
								if (mysqli_num_rows($result) > 0) 
								{
									while($row = mysqli_fetch_assoc($result)) 
									{
									echo '
									
                                    
                                
                                <div class="col-md-5 col-md-push-2">
                                <div id="product-main-img">
                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>
                                </div>
                            </div>
                                
                                <div class="col-md-2  col-md-pull-5">
                                <div id="product-imgs">
                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'g" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>
                                </div>
                            </div>

                                 
									';
                                    
									?>
									<!-- 弹性布局 -->
									
									<?php 
									echo '
									
                                    
                                   
                    <div class="col-md-5">
						<div class="product-details">
							<h2 class="product-name">'.$row['product_title'].'</h2>
							<div>
								<div class="product-rating">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star-o"></i>
								</div>
								<a class="review-link" href="#review-form">10个评测|添加您的评论</a>
							</div>
							<div>
								<h3 class="product-price">$'.$row['product_price'].'<del class="product-old-price">990块</del></h3>
								<span class="product-available">In Stock</span>
							</div>
							<p>自用省钱：平台不触碰资金完全没有资金安全这个担忧概念！领完优惠券直接去天猫，聚划算，淘宝就可购物结算发货，享受高级的优惠待遇。.</p>

							<div class="product-options">
								<label>
									尺寸
									<select class="input-select">
										<option value="0">X</option>
									</select>
								</label>
								<label>
									颜色
									<select class="input-select">
										<option value="0">红</option>
									</select>
								</label>
							</div>

							<div class="add-to-cart">
								<div class="qty-label">
									Qty
									<div class="input-number">
										
										<span class="qty-up">+</span>
										<span class="qty-down">-</span>
									</div>
								</div>
								<div class="btn-group" style="margin-left: 25px; margin-top: 15px">
								<button class="add-to-cart-btn" pid="'.$row['product_id'].'"  id="product" ><i class="fa fa-shopping-cart"></i> 添加到购物车</button>
                                </div>
								
								
							</div>

							<ul class="product-btns">
								<li><a href="#"><i class="fa fa-heart-o"></i>添加到愿望清单</a></li>
								<li><a href="#"><i class="fa fa-exchange"></i> 加入比较</a></li>
							</ul>

							<ul class="product-links">
								<li>类别：</li>
								<li><a href="#">头戴式耳机</a></li>
								<li><a href="#">配饰</a></li>
							</ul>

							<ul class="product-links">
								<li>分享：</li>
								<li><a href="#"><i class="fab fa-qq"></i></a></li>
								<li><a href="#"><i class="fab fa-weixin"></i></a></li>
								<li><a href="#"><i class="fas fa-reply-all"></i></a></li>
								<li><a href="#"><i class="fas fa-sms"></i></a></li>
							</ul>

						</div>
					</div>
									
					

					<div class="col-md-12">
						<div id="product-tab">

							<ul class="tab-nav">
								<li class="active"><a data-toggle="tab" href="#tab1">描述</a></li>
								<li><a data-toggle="tab" href="#tab2">细节</a></li>
								<li><a data-toggle="tab" href="#tab3">评论（3）</a></li>
							</ul>

							<div class="tab-content">
								<!-- tab1  -->
								<div id="tab1" class="tab-pane fade in active">
									<div class="row">
										<div class="col-md-12">
											<p>优品快报，0投资，0成本创业，真正利人利己。自用省钱：平台不触碰资金完全没有资金安全这个担忧概念！领完优惠券直接去天猫，聚划算，淘宝就可购物结算发货，享受高级的优惠待遇。佣金高：比很多做淘宝客的平台，不管返利还是其他的，优品快报佣金都是比他们高，实打实的给你，不用你掏钱买优惠券，再用现金返利给你。锁粉强裂变快：简单易复制，一次推荐终生锁定客户，很多代理两三天团队都达到500人了，只需手机号注册登陆即可，还能拿无限代佣金。推广期免加盟费，看懂了你来。.</p>
										</div>
									</div>
								</div>
								<!-- /tab1  -->

								<!-- tab2  -->
								<div id="tab2" class="tab-pane fade in">
									<div class="row">
										<div class="col-md-12">
											<p>为什么加入优品快报做合伙人可以如此轻松月入数万？因为快递单不用你写（天猫店家直接发货）不用你自己打包（还是商家做）不用你做售前回答问题（还是商家做）不用你售后处理麻烦（还是商家做）不用发愁产品单一（所有淘宝商品任你选）优品快报培训一条龙服务累活脏活公司全部包揽！你只管分享，销售，带团队！需要下载“优品快报”的可在各大应用商城手机360   或者应用宝 华为市场   都可以搜索 优品快报下载。</p>
										</div>
									</div>
								</div>
								<!-- /tab2  -->

								<!-- tab3  -->
								<div id="tab3" class="tab-pane fade in">
									<div class="row">

										<div class="col-md-3">
											<div id="rating">
												<div class="rating-avg">
													<span>4.5</span>
													<div class="rating-stars">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star-o"></i>
													</div>
												</div>
												<ul class="rating">
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
														</div>
														<div class="rating-progress">
															<div style="width: 80%;"></div>
														</div>
														<span class="sum">3</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div style="width: 60%;"></div>
														</div>
														<span class="sum">2</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
												</ul>
											</div>
										</div>

										<div class="col-md-6">
											<div id="reviews">
												<ul class="reviews">
													<li>
														<div class="review-heading">
															<h5 class="name">小王</h5>
															<p class="date">27 DEC 2018, 8:0 PM</p>
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
														</div>
														<div class="review-body">
															<p>学习最新赚钱方法。下载优品快报就可以自主搜索优惠券，成为合伙人便可以分享赚钱。用户粘度高，不需要维护，只要通过你的链接下载了二维码便是你的用户，以后只要是下单了就有佣金。</p>
														</div>
													</li>
													<li>
														<div class="review-heading">
															<h5 class="name">小花</h5>
															<p class="date">27 DEC 2018, 8:0 PM</p>
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
														</div>
														<div class="review-body">
															<p>背靠天猫淘宝大平台，我们只是提供优惠券，下单都在天猫淘宝，很安全！同时又比自己去天猫淘宝购买更优惠。</p>
														</div>
													</li>
													<li>
														<div class="review-heading">
															<h5 class="name">小兰</h5>
															<p class="date">27 DEC 2018, 8:0 PM</p>
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
														</div>
														<div class="review-body">
															<p>做优品快报，前期几个月是一个铺管道的过程，很枯燥，很无奈，但是一旦你的客户群体多了，自然而然做到交易不停，佣金不止！简单坚持去分享！轻易累积赚佣金！</p>
														</div>
													</li>
												</ul>
												<ul class="reviews-pagination">
													<li class="active">1</li>
													<li><a href="#">2</a></li>
													<li><a href="#">3</a></li>
													<li><a href="#">4</a></li>
													<li><a href="#"><i class="fa fa-angle-right"></i></a></li>
												</ul>
											</div>
										</div>

										<div class="col-md-3 mainn">
											<div id="review-form">
												<form class="review-form">
													<input class="input" type="text" placeholder="你的名字">
													<input class="input" type="email" placeholder="你的邮件">
													<textarea class="input" placeholder="你的意见"></textarea>
													<div class="input-rating">
														<span>你的评分： </span>
														<div class="stars">
															<input id="star5" name="rating" value="5" type="radio"><label for="star5"></label>
															<input id="star4" name="rating" value="4" type="radio"><label for="star4"></label>
															<input id="star3" name="rating" value="3" type="radio"><label for="star3"></label>
															<input id="star2" name="rating" value="2" type="radio"><label for="star2"></label>
															<input id="star1" name="rating" value="1" type="radio"><label for="star1"></label>
														</div>
													</div>
													<button class="primary-btn">提交</button>
												</form>
											</div>
										</div>

									</div>
								</div>
								<!-- /tab3  -->
							</div>

						</div>
					</div>

				</div>
				<!-- /行 -->
			</div>
			<!-- /容器 -->
		</div>
		<!-- /SECTION -->

		<!-- Section -->
		<div class="section main main-raised">

			<div class="container">
				<!-- 行->
				<div class="row">
                    
					<div class="col-md-12">
						<div class="section-title text-center">
							<h3 class="title">相关产品</h3>
							
						</div>
					</div>
                    ';
									$_SESSION['product_id'] = $row['product_id'];
									}
								} 
								?>	
								<?php
                    include 'db.php';
								$product_id = $_GET['p'];
                    
					$product_query = "SELECT * FROM products,categories WHERE product_cat=cat_id AND product_id BETWEEN $product_id AND $product_id+3";
                $run_query = mysqli_query($con,$product_query);
                if(mysqli_num_rows($run_query) > 0){

                    while($row = mysqli_fetch_array($run_query)){
                        $pro_id    = $row['product_id'];
                        $pro_cat   = $row['product_cat'];
                        $pro_brand = $row['product_brand'];
                        $pro_title = $row['product_title'];
                        $pro_price = $row['product_price'];
                        $pro_image = $row['product_image'];

                        $cat_name = $row["cat_title"];

                        echo "
				
                        
                                <div class='col-md-3 col-xs-6'>
								<a href='product.php?p=$pro_id'><div class='product'>
									<div class='product-img'>
										<img src='product_images/$pro_image' style='max-height: 170px;' alt=''>
										<div class='product-label'>
											<span class='sale'>-30%</span>
											<span class='new'>新</span>
										</div>
									</div></a>
									<div class='product-body'>
										<p class='product-category'>$cat_name</p>
										<h3 class='product-name header-cart-item-name'><a href='product.php?p=$pro_id'>$pro_title</a></h3>
										<h4 class='product-price header-cart-item-info'>$pro_price<del class='product-old-price'>990.00</del></h4>
										<div class='product-rating'>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
										</div>
										<div class='product-btns'>
											<button class='add-to-wishlist'><i class='fa fa-heart-o'></i><span class='tooltipp'>添加到愿望清单</span></button>
											<button class='add-to-compare'><i class='fa fa-exchange'></i><span class='tooltipp'>加入比较</span></button>
											<button class='quick-view'><i class='fa fa-eye'></i><span class='tooltipp'>快速浏览</span></button>
										</div>
									</div>
									<div class='add-to-cart'>
										<button pid='$pro_id' id='product' class='add-to-cart-btn block2-btn-towishlist' href='#'><i class='fa fa-shopping-cart'></i>添加到购物车</button>
									</div>
								</div>
                                </div>
							
                        
			";
		}
        ;
      
}
?>

				</div>

                
			</div>

		</div>

<?php
include "newslettter.php";
include "footer.php";

?>
