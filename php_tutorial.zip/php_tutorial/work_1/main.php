<!DOCTYPE html>
<html>
<head>
    <title>主页</title>
    <meta charset="utf-8">
</head>
<frameset rows="20%,*">
    <frame src="top.php" name="top" noresize></frame>
    <frameset cols="20%,*">
        <frame src="left.php" name="left" noresize></frame>
        <frame src="right.php" name="right"></frame>
    </frameset>
</frameset>
</html>

