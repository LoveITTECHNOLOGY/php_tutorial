<!DOCTYPE html>
<html>
<head>
    <title>lift</title>
    <meta charset="utf-8">
</head>
<style type="text/css">
    body{background: #00cd66;}
    .left{margin-top:25px;margin-left:30px;}
    a{color:snow;text-decoration:none;}
    a:hover{color:red;}
</style>
<body>
<div class="left">
    <h3><a href="user/user.php" target="right">>>管理员管理</a></h3>
    <h3><a href="about/about.php" target="right">>>关于我们</a></h3>
    <h3><a href="news/news.php" target="right">>>新闻资讯</a></h3>
    <h3><a href="project/product.php" target="right">>>产品管理</a></h3>
    <h3> <a href="contact/contact.php" target="right">>>联系我们</a></h3>
</div>
</body>
</html>
