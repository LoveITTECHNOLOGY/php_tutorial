<html>

<body style="background:linear-gradient(to right,red,blue)">
<p align="center">请填写个人信息</p>

<form action="add_user_check.php" method="post">
    <table border="1" align="center">
        <tr><th>用户名<input type="text" name="username">*</th></tr>
        <tr><th> <br>密码<input type="text" name="password">*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>