<?php

$conn=mysql_connect("localhost","root","");
//开始连接数据库表
mysql_select_db("article",$conn);
//开始将内容转换为中文字符
mysql_query("set names UTF8");
$id=intval($_GET["id"]);
echo $id;
if(isset($_GET['id'])&&!empty($_GET['id']))
    $id=intval($_GET['id']);
$sql="select * from admin where id=$id";
$result=mysql_query($sql);
$row=mysql_fetch_assoc($result);

?>

<html>

<body bgcolor="#f0ffff">
<p align="center">更新数据</p>

<form  method="post"  action="update_user_check.php?id=<?php echo $row['id'];?>">
    <table border="1" align="center">
        <tr><th>用户名<input type="text" name="username" value="<?php echo$row['username'];?>"/>*</th></tr>
        <tr><th> <br>密码<input type="text" name="password" value="<?php echo$row['password'];?>"/>>*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>