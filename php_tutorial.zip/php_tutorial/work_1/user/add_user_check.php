<?php
require_once('../config.php'); //连接数据库



//开始传值
$username=$_POST['username'];
$password=$_POST['password'];


//开始插入sql语句
mysqli_query($link,"insert into admin(username,password)
VALUES ('".$username."','".$password."')");
//开始返回主页面
header("location:user.php");
?>