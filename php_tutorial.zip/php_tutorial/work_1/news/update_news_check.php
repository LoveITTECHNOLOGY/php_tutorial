<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/19
 * Time: 14:46
 */

$conn=mysql_connect("localhost","root","");
//开始设置为中文字符
mysql_query("set names UTF8");
//开始连接数据库表名
mysql_select_db("article",$conn);
$id=intval($_GET['id']);
$title=$_POST['title'];
$content=$_POST['content'];
$sql="update news set title='$title',content='$content' where id=".$id;
$r=mysql_query($sql);
if($r)
    echo "<script>alert('修改成功');
location.href='news.php';</script>";
?>