<?php
require_once('../config.php'); //连接数据库



//开始传值
$title=$_POST['title'];
$content=$_POST['content'];


//开始插入sql语句
mysqli_query($link,"insert into news(title,content)
VALUES ('".$title."','".$content."')");
//开始返回主页面
header("location:news.php");
?>