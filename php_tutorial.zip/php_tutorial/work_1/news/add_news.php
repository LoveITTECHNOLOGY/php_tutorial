<html>

<body style="background:linear-gradient(to right,red,blue)">
<p align="center">请填写新闻信息</p>

<form action="add__news_check.php" method="post">
    <table border="1" align="center">
        <tr><th>公司新闻<input type="text" name="title">*</th></tr>
        <tr><th> <br>公司公告<input type="text" name="content">*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>