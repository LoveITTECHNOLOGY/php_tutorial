<?php
$link=mysqli_connect("localhost","root","","article");
$link->set_charset("UTF8");
?>