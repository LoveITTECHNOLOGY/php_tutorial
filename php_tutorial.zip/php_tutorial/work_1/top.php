<?php
session_start();
if(@$_GET['act'] =='loginout') {
    unset($_SESSION);
    echo "<script>location.href='login/login.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
    <style type="text/css">
        body{margin-top:50px;text-align:center;background: #00cd66;color:white}
        a{color:white;}
    </style>
</head>
<body >
<h1>企业网站后台管理系统</h1>
<?php if(!empty($_SESSION['username'])){ ?>
当前登录的管理员是：<?php echo $_SESSION['username'] ?>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="?act=loginout " target="_parent">退出系统</a>
<?php } ?>
</body>
</html>