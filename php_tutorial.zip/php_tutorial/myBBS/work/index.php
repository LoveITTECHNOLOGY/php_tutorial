<?php
session_start();
if(@$_GET['act']=="loginout"){
    $_SESSION['username']='';
    ?>
    <script>
        location.href="?";
    </script>
    <?php
    exit;
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mybbs";
// 创建连接
$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_query($conn,'set names utf8'); //设定字符集
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>论坛</title>
    <style>
        .cen{
            width: 55%;
            margin: 0 auto;
            text-align: right;
            margin-top: 30px;
        }
        table{
            width: 55%;
            margin-top: 10px;
        }
        .title{
            background-color: #B10707;
            font-size: 17px;
            color: white;
        }
        .right{
            margin-left: 120px;
        }
    </style>
</head>
<body>
<div class="cen">
    <?php
    if(@$_SESSION['username']){
        ?>
        <a href="?act=loginout">退出</a>
    <?php }
    else{
        ?>
        <a href="login.php">登录</a>|<a href="reg.php">注册</a>
    <?php
    }
    ?>
</div>
<div>
    <html>
    <meta charset="UTF-8">
    <?php

    $f=fopen("time.txt",'r+');
    $visit=fgets($f);
    //$_SESSION['connected']=null;
    //防刷机制
    if(!$_SESSION['connected'])
    {
        $visit=$visit++;
        $_SESSION['connected']=true;
    }
    $countlen=strlen($visit);
    $num=null;
    for($i=0;$i<$countlen;$i++)
        $num=$num."<img src=img/".substr($visit,$i,1). ".gif></img>";

    rewind($f);
    fwrite($f,$visit);
    fclose($f);
  

    ?>
    <html>
    <meta charset="UTF-8">
    <body>
    <h2>欢迎来我的主页</h2>
    你是第<p class="num1"><?php echo $visit;?></p>位访问者!
    </body>
    <style>
        .num1
        {
            color: #000000;
            font-size: 20px;
            font-family: slick;
            border: 1px solid #fff6af;
            font-style:normal;
            background: linear-gradient(to right,white,green);
            width: 70px;
            text-align: center;
            height: 30px;

        }
    </style>
    </html>
</div>



<table align="center">
<tr align="center">
<td>
    <form method="get" action="chaxun.php">
        <div style="....">


            请输入查询关键字<input name="keyword" type="text">
            <select name="sel">

                <option value="subject">主题</option>
                <option value="forum_name">论坛</option>
            </select>
            <input type="submit"  value="查询">
        </div>



    </form>


</td>
</tr>
</table>
<table border="1px" cellspacing="0" cellpadding="8"align="center">
    <tr class="title">
        <td COLSPAN="3">
            论坛列表<span class="right">[<a style="color: white" href="add_forum.php">添加</a> ]</span>
        </td>
    </tr>
    <tr>
        <td width="10%"><strong>主题</strong></td>
        <td width="40"><strong>论坛</strong></td>
        <td width="15"><strong>最后更新</strong></td>
        <td width="15"><strong>操作</strong></td>
        <td width="15"><strong>操作</strong></td>


    </tr>
    <?php
    $sql="select * from forums";
    $que=mysqli_query($conn,$sql);
    $sum=mysqli_num_rows($que);
    if($sum>0) {
        while ($row = mysqli_fetch_array($que)) {
            ?>
            <tr>
                <td><?php echo $row['subject'] ?></td>
                <td><?php echo "<div class=\"bold\"><a class=\"forum\" href=\"forums.php?F=" . $row['id'] . "\">" . $row["forum_name"] . "</a></div>"
                        . $row["forum_description"] ?></td>
                <td>
                    <div><?php echo $row["last_post_time"]?></div>
                </td>
                <td align = "center"><a href="delete.php?id=<?php echo $row['id'];?>">删除</a> </td>
                <td align="center"><a href="update.php?id=<?php echo $row['id'];?>">修改</a> </td>

            </tr>
        <?php
        }
    }else{
        echo "<tr><td colspan='3'>对不起，论坛正在建设中，感谢你的关注......</td></tr>";
    }
    ?>
</table>
</body>
</html>