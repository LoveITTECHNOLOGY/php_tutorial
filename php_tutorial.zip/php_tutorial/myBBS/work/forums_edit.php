<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/19
 * Time: 14:46
 */
require('conn.php');
$id=intval($_GET['id']);
$author=$_POST['author'];
$sql="update tiopic set author='$author' where id=".$id;
$r=mysql_query($sql);
if($r)
    echo "<script>alert('修改成功');
location.href='forums_pdae.php';</script>";
?>