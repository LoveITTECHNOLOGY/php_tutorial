<?php
$num=0;//$num用来统计子目录和文件的总数
$dir='../work';
$dirth=opendir($dir);
?>
<table border="1" width="600">
    <caption><b>目录<?php echo $dir;?>中的内容</b></caption>
    <tr align="left" bgcolor="#faebd7">
        <th>文件名</th><th>大小</th><th>类型</th><th>创建时间</th><th>修改时间</th>
        <?php
           while($file=readdir($dirth)){
               if($file!='.'&&$file!==".."){
                   $dirfile=$dir."/".$file;
                   $num++;
                   $bgcolor='#faebd7';
                   echo '<tr bgcolor='.$bgcolor.'>';
                   echo '<td>'.$file.'</td>';
                   echo '<td>'.filesize($dirfile).'</td>';
                   echo '<td>'.filetype($dirfile).'</td>';
                   echo "<td>".date('Y-m-d H:s:i',filectime($file)).'</td>';
                   echo '<td>'.date("Y/n/t",filemtime($dirfile)).'</td>';
               }

           }
        closedir($dirth);
        ?>
    </tr>
</table>
在<b><?php echo $dir; ?></b>目录下的子目录和文件共有<b><?php echo $num;?></b>
<html>
<meta charset="utf-8">
</html>