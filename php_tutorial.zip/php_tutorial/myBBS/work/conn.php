<?php
$conn=mysql_connect("localhost","root","");
mysql_query("set names UTF8");
mysql_select_db("mybbs",$conn);
?>