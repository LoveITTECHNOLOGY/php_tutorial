<?php
require('conn.php');
$selected = $_POST['selected'];
if(count($selected)>0){
    $sel = implode(',',$selected);
    $sql = "delete from tiopic where id in($sel)";
    mysql_query($sql);
    echo"<script>alert('确定要删除！');
    location.href='forums.php';</script>";
}else
    echo"没有被选中的记录";
?>
