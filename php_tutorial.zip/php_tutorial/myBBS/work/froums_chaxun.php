
<h3 align="center">查询结果</h3>
<meta charset="UTF-8">

<?php
require('conn.php');
require('func_page.php');
$PageSize=6;
if(isset($_GET['Page'])&&(int)$_GET['Page']>0)
    $page=$_GET['Page'];
else $page=1;
$keyword=$_GET['keyword'];
$sel=trim($_GET['sel']);
//echo $keyword.$sel;
$sql="select * from tiopic ";
if($keyword<>"")
        $sql=$sql."where $sel like '%$keyword%'";
//echo $sql;a
$result=mysql_query($sql);
$t=mysql_num_rows($result);
$RecordCount=$t;
//$PageCount=ceil($RecordCount/$PageSize);
//mysql_free_result($result);
//$result=mysql_query("select * from user where $sel like '%$keyword%' limit ". ($page-1)*$PageSize.",".$PageSize,$conn);
?>
<body style="background-color: aqua">
<table border="1" width="95%" align="center" a>
    <tr bgcolor="#5f9ea0">

    </tr>
    <?PHP
    mysql_data_seek($result,($page-1)*$PageSize);
    for($i=0;$i<$PageSize;$i++){
        $row=mysql_fetch_assoc($result);
        if($row)
        {?>
            <tr><td ><?php echo $row['title']?></td>
                <td><?php echo $row['author']?></td>
                <td align="center"><a href="delete.php?id=<?php echo $row['id'];?>">删除</a> </td>
                <td align="center"><a href="update.php?id=<?php echo $row['id'];?>">修改</a> </td>
            </tr>

        <?php }}
    mysql_free_result($result)
    ?>
</table>



<?php
$url=$_SERVER["PHP_SELF"];
page($RecordCount,$PageSize,$page,$url,$keyword,$sel);
?>
</body>