<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/12
 * Time: 20:15
 */
//连接数据库
$conn=mysql_connect("localhost","root","");
mysql_query("set names UTF8");
mysql_select_db("mybbs",$conn);
//开始传值
$forum_name=$_POST['forum_name'];
$forum_description=$_POST['forum_description'];
$subject=$_POST['subject'];



//开始插入数据
mysql_query("insert into forums(forum_name,forum_description,subject)
VALUES('".$forum_name."','".$forum_description."','".$subject."') ");


//返回主页
header("location:index.php");
?>
