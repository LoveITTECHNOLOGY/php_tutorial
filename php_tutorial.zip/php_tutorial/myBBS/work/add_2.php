<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始连接数据库表名
mysql_select_db("mybbs",$conn);
//对查询的内容设置为中文字符
mysql_query("set names 'UTF8'");


//开始传值
$username=$_POST['username'];
$password=$_POST['password'];
$email=$_POST['email'];

//开始插入sql语句
mysql_query("insert into member(username,password,email)
VALUES ('".$password."','".$username."','".$email."')");
//开始返回主页面
header("location:login.php");
?>