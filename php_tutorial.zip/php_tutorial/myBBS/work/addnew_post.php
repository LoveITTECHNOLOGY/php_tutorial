<?php

//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始设置为中文字符
mysql_query("set names UTF8");
//开始连接数据库表名
mysql_select_db("mybbs",$conn);
//开始传值
$author=$_POST['author'];
$title=$_POST['title'];
$content=$_POST['content'];
//开始插入到数据库中
mysql_query("insert into tiopic(author,title,content)
VALUES ('".$author."','".$title."','".$content."')");

//开始返回主页面
header("location:forums.php");
?>