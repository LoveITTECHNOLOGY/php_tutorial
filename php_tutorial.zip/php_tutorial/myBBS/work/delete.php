<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("mybbs",$conn);
mysql_query("set names 'UTF8'");
$id = intval($_GET["id"]);


$sql = "delete from forums where id= $id";
if(mysql_query($sql)&&mysql_affected_rows()==1)
    echo "<script>alert('删除成功！');
location.href = 'index.php'</script>";
else
    echo "<script>alert('删除失败！');
loation.href = 'index.php'</script>";

?>