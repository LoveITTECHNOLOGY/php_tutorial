<?php

//开始连接数据库
require('conn.php');

//开始传值
$reply_author=$_POST['reply_author'];
$reply=$_POST['reply'];


//开始插入数据库、
mysql_query("insert into tiopic(reply,reply_author)
VALUES ('".$reply."','".$reply_author."')");


//开始返回查看区域
header("location:thread.php");
?>