<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/19
 * Time: 14:46
 */
require('conn.php');
$id=intval($_GET['id']);
$forum_name=$_POST['forum_name'];
$subject=$_POST['subject'];
$forum_description=$_POST['forum_description'];
$sql="update forums  set forum_name='$forum_name',subject='$subject'
,forum_description='$forum_description' where id=".$id;
$r=mysql_query($sql);
if($r)
    echo "<script>alert('修改成功');
location.href='index.php';</script>";
?>