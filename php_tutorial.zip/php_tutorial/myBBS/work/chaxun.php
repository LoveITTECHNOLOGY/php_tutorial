<h3 align="center">查询结果</h3>

<?php

require('conn.php');
$keyword=$_GET['keyword'];
$sel=trim($_GET['sel']);
$sql="select * from forums ";
if($keyword<>"")
$sql=$sql."where  $sel like '%$keyword%'";
$result=mysql_query($sql);
$t=mysql_num_rows($result);
if($t>0){
    echo "<p>关键字为<35:".$keyword.",共找到".$t."条记录</p>";
}
?>

<table border="1" width="95%" bgcolor="aqua">
    <tr bgcolor="#faebd7">
        <td>主题</td>
        <td>论坛</td>

    </tr>


    <?php while($row=mysql_fetch_assoc($result)){
        ?>

        <tr>
            <td><?php echo $row['subject'];?></td>
            <td><?php echo $row['forum_name'];?></td>



        </tr>
    <?php }?>

    <h3><a href="index.php">返回</a> </h3>
</table>

