
<h3 align="center">查询结果</h3>
<meta charset="UTF-8">

<?php
require('conn.php');
require('func_page.php');
$PageSize=4;
if(isset($_GET['Page'])&&(int)$_GET['Page']>0)
    $page=$_GET['Page'];
else $page=1;
$keyword=$_GET['keyword'];
$sel=trim($_GET['sel']);
//echo $keyword.$sel;
$sql="select * from user ";
if($keyword<>"")
    if($sel=='age')
        $sql=$sql." where $sel>$keyword";
    else
        $sql=$sql."where $sel like '%$keyword%'";
//echo $sql;a
$result=mysql_query($sql);
$t=mysql_num_rows($result);
$RecordCount=$t;
//$PageCount=ceil($RecordCount/$PageSize);
//mysql_free_result($result);
//$result=mysql_query("select * from user where $sel like '%$keyword%' limit ". ($page-1)*$PageSize.",".$PageSize,$conn);
if($t>0){
    echo "<p>关键字为：>".$keyword.",共找到".$t."条记录</p>";
}
?>

<table border="1" width="95%" align="center" a>
    <tr bgcolor="#5f9ea0">
        <th width="50">序号</th>
        <th width="50" >姓名</th>
        <th width="50" >性别</th>
        <th width="50" >年龄</th>
        <th width="80">住址</th>
        <th width="100">联系方式</th>
        <th width="50">操作</th>
        <th width="50">操作</th>
    </tr>
    <?PHP
    mysql_data_seek($result,($page-1)*$PageSize);
    for($i=0;$i<$PageSize;$i++){
        $row=mysql_fetch_assoc($result);
        if($row)
        {?>
            <tr><td ><?php echo $row['numer']?></td>
                <td><?php echo $row['name']?></td>
                <td><?php echo  $row['sex']?></td>
                <td><?php echo $row['age']?></td>
                <td ><?php echo $row['addr']?></td>
                <td><?php echo  $row['tel']?></td>
                <td align="center"><a href="delete.php?id=<?php echo $row['numer'];?>">删除</a> </td>
                <td align="center"><a href="update.php?id=<?php echo $row['numer'];?>">修改</a> </td>
            </tr>

        <?php }}
    mysql_free_result($result)
    ?>
</table>

<h3> <a href="index.php">返回</a> </h3>

<?php
$url=$_SERVER["PHP_SELF"];
page($RecordCount,$PageSize,$page,$url,$keyword,$sel);
?>