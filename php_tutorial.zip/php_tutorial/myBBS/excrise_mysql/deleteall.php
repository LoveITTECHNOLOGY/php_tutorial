<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/17
 * Time: 10:18
 */
//开始连接数据库
$conn=mysql_connect("localhost","root","");
mysql_query("set names UTF8");
mysql_select_db("mybook",$conn);
$selected=$_POST['selected'];
if(count($selected)>0){
    //转换为字符串
    $sel=implode(',',$selected);
    $sql="delete from user where numer in($sel)";
    mysql_query($sql);
    echo "<script>alert('确定要删除!');
    location.href='detall.php';</script>";


}else
    echo "没有被选中的记录";
?>