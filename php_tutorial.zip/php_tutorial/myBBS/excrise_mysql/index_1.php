<meta charset="UTF-8">
<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据表名
mysql_select_db("mybook",$conn);
//开始将连接表名设置为中文字符
mysql_query("set names 'UTF8'");
$PageSize=5;

//开始执行sql语句
$result=mysql_query("select count(*)  from user",$conn);
$row=mysql_fetch_row($result);


$RecordCount=$row[0];
$PageCount=ceil($RecordCount/$PageSize);
//开始释放资源
mysql_free_result($result);
if(isset($_GET['page'])&&(int)$_GET['page']>0)
$page=$_GET['page'];
else   $page=1;
//$result=mysql_query("select * from user limit ".($page-1)*$PageSize.",".$PageSize,$conn);
//结果集
$result=mysql_query("select *  from user");



?>
<body bgcolor="#ffe4c4">
<h2 align="center">欢迎来到人事管理系统</h2>
<table border="0" width="95%" align="center">
<tr><td><a href="register_1.php">增加人员信息</a></td>
    <td>
        <form method="get" action="chaxun.php">
            <div style="....">


                查找人员，请输入查询关键字<input name="keyword" type="text">
                <select name="sel">

                    <option value="name">姓名</option>
                    <option value="sex">性别</option>
                    <option value="age">年龄</option>
                    <option value="addr">住址</option>
                </select>
                <input type="submit"  value="查询">
            </div>



        </form>


    </td>
</tr>
</table>
<table border="1" width="95%">

    <tr bgcolor="#deb887">
        <th>序号</th>
        <th>姓名</th>
        <th>性别</th>
        <th>年龄</th>
        <th>家庭住址</th>
        <th>手机号码</th>
        <th>删除</th>
        <th>操作</th>
    </tr>



    <?php
    //通过指针定位来实现分页 1，2，3
    mysql_data_seek($result,($page-1)*$PageSize);
    for($i=0;$i<$PageSize;$i++){
        $row=mysql_fetch_assoc($result);
        if($row){


        ?>

        <tr>
            <td><?php echo $row['numer'];?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['sex'];?></td>
            <td><?php echo $row['age'];?></td>
            <td><?php echo $row['addr'];?></td>
            <td><?php echo $row['tel'];?></td>
            <td align="center"><a href="delete.php?id=<?php echo $row['numer'];?>">删除</a> </td>
                       <td align="center"><a href="update.php?id=<?php echo $row['numer'];?>">修改</a> </td>



        </tr>
    <?php }}
    mysql_free_result($result);
    ?>
</table>
<p align="center">
<?php
if($page==1)
    echo "首页 上一页";
else
    echo "<a href='?page=1'>首页</a>
    <a href='?page=".($page-1)."'>上一页</a>";
for($i=1;$i<=$PageCount;$i++){
    if($i==$page)echo "$i ";
    else echo "<a href='?page=$i'>$i </a>";

}
if($page==$PageCount)
    echo "下一页 末页";
else
    echo "<a href='?page=".($page+1)."'>下一页</a>
    <a href='?page=".$PageCount."'>末页</a>";
echo "&nbsp 共".$RecordCount."条记录&nbsp";
echo "$page/$PageCount 页";





?>


</p>
</body>