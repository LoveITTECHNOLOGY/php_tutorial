<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据表名
mysql_select_db("mybook",$conn);
//开始将连接表名设置为中文字符
mysql_query("set names 'UTF8'");
//开始执行sql语句
$result=mysql_query("select * from user",$conn);
?>
<body bgcolor="#7fffd4">
<p align="center">欢迎来到人事管理系统</p>
<a href="register_1.php">增加人员信息</a>
<form method="post" action="deleteall.php">

<table border="1" width="95%">

    <tr bgcolor="#deb887">
        <th>序号</th>
        <th>姓名</th>
        <th>性别</th>
        <th>年龄</th>
        <th>家庭住址</th>
        <th>手机号码</th>
        <th>操作</th>
    </tr>



    <?php while($row=mysql_fetch_assoc($result)){
        ?>

        <tr>
            <td><?php echo $row['numer'];?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['age'];?></td>
            <td><?php echo $row['sex'];?></td>
            <td><?php echo $row['addr'];?></td>
            <td><?php echo $row['tel'];?></td>
            <td align="center">
                <input type="checkbox" name="selected[]"
                       value="<?php echo $row['numer'];?> ">
            </td>



        </tr>
    <?php }?>
    <tr bgcolor="#ffe4c4">
        <td></td><td></td><td></td><td></td><td></td><td></td>
        <td align="center"><input type="submit" value="删除"></td>
    </tr>
</table></form>
</body>