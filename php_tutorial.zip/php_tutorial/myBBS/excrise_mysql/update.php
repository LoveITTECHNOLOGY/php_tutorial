<?php
require('conn.php');
if(isset($_GET['id'])&&!empty($_GET['id']))
$id=intval($_GET['id']);
$sql="select * from user where numer=$id";
$result=mysql_query($sql);
$row=mysql_fetch_assoc($result);

?>

<html>

<body bgcolor="#f0ffff">
<p align="center">更新数据</p>

<form  method="post"  action="edit.php?id=<?php echo $row['numer'];?>">
    <table border="1" align="center">
        <tr><th>用户名<input type="text" name="name" value="<?php echo$row['name'];?>"/>*</th></tr>
        <tr><th> <br>年龄<input type="text" name="age" value="<?php echo$row['age'];?>"/>>*</br></th></tr>
        <tr><th><br>性别<input type="text" name="sex" value="<?php echo $row['sex'];?>"/>*</br></th></tr>
        <tr><th><br>家庭住址<input type="text" name="addr" value="<?php echo$row['addr'];?>"/>*</br></th></tr>
        <tr><th> <br>手机号码<input type="text" name="tel" value="<?php echo$row['tel'];?>"/>*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>