<?php

//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据库
mysql_select_db("mybook",$conn);
//开始将查询的内容设置成中文
mysql_query("set names 'UTF8'");
//开始传值
$name=$_POST['name'];
$age=$_POST['age'];
$sex=$_POST['sex'];
$tel=$_POST['tel'];
$addr=$_POST['addr'];
//开始插入内容
mysql_query("insert into user(name,age,sex,tel,addr)
VALUES ('".$name."','".$age."','".$sex."','".$tel."','".$addr."')");
//开始返回主页面
header("location:index_1.php");
?>