<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/19
 * Time: 14:46
 */
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始连接数据库表
mysql_select_db("mybook",$conn);
//开始将内容转换为中文字符
mysql_query("set names UTF8");
$id=intval($_GET['id']);
$name=$_POST['name'];
$sex=$_POST['sex'];
$age=$_POST['age'];
$addr=$_POST['addr'];
$tel=$_POST['tel'];
$sql="update user set name='$name',sex='$sex',age='$age',
addr='$addr',tel='$tel' where numer=".$id;
$r=mysql_query($sql);
if($r)
    echo "<script>alert('修改成功');
location.href='index_1.php';</script>";
?>