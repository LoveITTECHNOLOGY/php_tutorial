<p><?php
    $page=3;
    $PageSize=4;
    $RecordCount=20;
    $PageCount=ceil($RecordCount/$PageSize);
    if($page==1)
    echo "首页 上一页";
    else
    echo "<a href='?page=1'>首页</a>
    <a href='?page=".($page-1)."'>上一页</a>";
    for($i=1;$i<=$PageCount;$i++){
        if($i==$page)echo "$i ";
        else echo "<a href='?page=$i'>$i </a>";

    }
    if($page==$PageCount)
    echo "下一页 末页";
    else
    echo "<a href='?page=".($page+1)."'>下一页</a>
    <a href='?page=".$PageCount."'>末页</a>";





        ?>



    </p>