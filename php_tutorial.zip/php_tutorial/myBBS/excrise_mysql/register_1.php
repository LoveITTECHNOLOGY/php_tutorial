<html>

<body bgcolor="#f0ffff">
<p align="center">请填写个人信息</p>

<form action="add_1.php" method="post">
    <table border="1" align="center">
    <tr><th>用户名<input type="text" name="name">*</th></tr>
        <tr><th> <br>年龄<input type="text" name="age">*</br></th></tr>
        <tr><th><br>性别<input type="text" name="sex">*</br></th></tr>
        <tr><th><br>家庭住址<input type="text" name="addr">*</br></th></tr>
        <tr><th> <br>手机号码<input type="text" name="tel">*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>